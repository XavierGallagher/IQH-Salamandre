﻿# -*- coding: utf-8 -*-
"""
Script générale pour le calcul de l'IQH de la salamandre poupre.
version préliminaire.

Créer par la Sal'Équipe dans le cadre du cours APP de l'université de Sherbrooke
        Gabriel Boisvert
        Xavier Gallagher-Duval
        Audrey Oliver

        Avril 2018
"""

#Importation des librairies
import arcpy
import arcpy.mapping as mapping
from arcpy.sa import *
import os
import csv
import sys
#***modifier le chemin selon le système***
# sys.path.append(r"C:\Users\cuistooo\Documents\rpy2-2.9.3")
# import rpy

# on vérifit que la licence spatial analyse est disponible.
arcpy.CheckOutExtension("spatial")
#

# importation des toolbox nécessaires
# ***le chemin doit être mis à jour selon l'ordinateur utilisé***
chemin = r"D:/APP2/Conception modules/FeatureLineSplit-master/FeatureLineSplit-master/Feature Line Split.tbx"
arcpy.ImportToolbox(chemin)
   # r"D:/APP2/Conception modules/FeatureLineSplit-master/FeatureLineSplit-master/Feature Line Split.tbx")


def projetCouche(projection, couche, workspace, name):
        """
        Fonction qui regarde si la projection de la couche est égale à la projection voulu par l'utilisateur
        lorsque la couche n'est pas dans la même projection il la transforme.
        Arg:
            projection: Projettion du mnt
            couche: shapefile désirer.
            workspace: espace de travail contenant toutes les couches du projet
        """

        descFeature = arcpy.Describe(couche)

        featName = descFeature.baseName
        inSr = descFeature.spatialReference
        inSrName = descFeature.spatialReference.name

        # si la projection de la couche et du mnt sont pareil on dit a l'utilisateur que les références spatiales sont les mêmes et on copie l'entité dans l'espace de traveil en la renommant
        if inSrName == projection.name:
            arcpy.AddMessage(
                "La couche est dans la bonne référence spatiale, l'entité sera copier dans la gdb de travail")
            arcpy.CopyFeatures_management(couche, workspace + "\{}_p".format(name))

       # si la projection n'est pas la même
        else:

            #On essais de faire la projection avec une transformation
            try:

                # On sort ensuite la liste des transformation possible pour passé de la projection de la couche à celle du mnt
                tranformation = arcpy.ListTransformations(inSr, projection)
                arcpy.AddMessage("{}".format(tranformation[0]))

                # On projet les couches à l'aide de la première tranformation de la liste
                arcpy.Project_management(couche, workspace + "\{}_p".format(name), projection, tranformation[0])

            #s'il n'y a pas de transformation on fait la projection
            except:
                # On projet les couche en wgs84 à l'aide de la première tranformation de la liste
                arcpy.Project_management(couche, workspace + "\{}_p".format(name), projection)

def decoupeFeature( workspace):
    """
    Fonction qui découpe les divers couches projeter selon la zone d'étude.
    Arg:
        workspace: Espace de travail
    """

    #liste les couches contenu dans l'espace de travail
    couches = arcpy.ListFeatureClasses()

    #pour toutes les couches dans l'espace de travail on sort les éléments type et nom
    for couche in couches:
        descFeauture = arcpy.Describe(couche)
        name = descFeauture.baseName
        type = descFeauture.datasetType

        #si la couche a pour nom Zone_p on  la définit comme étant la zone
        if name == "Zone_p":
            zone = couche

        #Si la couche a pour type FeatureClass on la découpe selon la zone
        if type == "FeatureClass" and name != "Zone_p":
             arcpy.Clip_analysis(couche, zone, workspace+"/"+name+"_clip")


def pointsAbs(Ecofo, Occurences, workspace):
    """
    Fonction traduit d'un modèle builder, elle permet de créer les points d'absence en vue de créer un modèle d'IQH.
    Les points d'abesence sont créer dans les polygones écoforestier ne contenant pas de point de présence.
    Arg:
        Ecofo: Couche écoforestière cliper et projeter selon la zone d'étude
        Occurences: Les points de présence de salamande
        workspace: l'espace de travail
    """

    Expression = "GR_ESS <> 'N'"
    Selection_type = "SWITCH_SELECTION"


    # Process: Make Feature Layer
    ecofoL = arcpy.MakeFeatureLayer_management(Ecofo, "Ecofo_1", "", "", "OBJECTID OBJECTID VISIBLE NONE;Shape Shape VISIBLE NONE;NO_ATLAS NO_ATLAS VISIBLE NONE;OBSERVATEU OBSERVATEU VISIBLE NONE;ORGANISATI ORGANISATI VISIBLE NONE;STATUT_DON STATUT_DON VISIBLE NONE;NOM_COMMUN NOM_COMMUN VISIBLE NONE;CODE_ESP CODE_ESP VISIBLE NONE;LONDD LONDD VISIBLE NONE;LATDD LATDD VISIBLE NONE;NO_STATION NO_STATION VISIBLE NONE;PRECISION PRECISION VISIBLE NONE;REGION REGION VISIBLE NONE;VILLE VILLE VISIBLE NONE;DESCR_LIEU DESCR_LIEU VISIBLE NONE;HABITAT HABITAT VISIBLE NONE;HEURE HEURE VISIBLE NONE;DATE_JOUR DATE_JOUR VISIBLE NONE;DATE_MOIS DATE_MOIS VISIBLE NONE;DATE_ANNEE DATE_ANNEE VISIBLE NONE;TYPE_OBSER TYPE_OBSER VISIBLE NONE;NB_ADULTE NB_ADULTE VISIBLE NONE;NB_JUVENIL NB_JUVENIL VISIBLE NONE;NB_OEUFS NB_OEUFS VISIBLE NONE;NOMBRE_TOT NOMBRE_TOT VISIBLE NONE;COTE_CHANT COTE_CHANT VISIBLE NONE;COMMENTAIR COMMENTAIR VISIBLE NONE;REMARQUE REMARQUE VISIBLE NONE;SOURCE SOURCE VISIBLE NONE;DATE_SAISI DATE_SAISI VISIBLE NONE;SAISIE_PAR SAISIE_PAR VISIBLE NONE;VALIDATION VALIDATION VISIBLE NONE;PHOTO_NOM_ PHOTO_NOM_ VISIBLE NONE")

    # Process: Select Layer By Location
    ecofoLS = arcpy.SelectLayerByLocation_management(ecofoL, "INTERSECT", Occurences, "", Selection_type)

    # Process: Select Layer By Attribute
    ecofoLSS = arcpy.SelectLayerByAttribute_management(ecofoLS, "SUBSET_SELECTION", Expression)

    # Process: Dissolve
    ecofoFus = arcpy.Dissolve_management(ecofoL, workspace+"\ecofus", "", "", "MULTI_PART", "DISSOLVE_LINES")

    # Process: Get Count
    Row_Count = arcpy.GetCount_management(Occurences)

    # Process: Create Random Points
    PointRandom = arcpy.CreateRandomPoints_management(workspace, "absence", ecofoFus, "0 0 250 250", Row_Count, "0 Meters", "POINT", "0")

    return PointRandom

def pretraitementEco(Carte_Eco):
    """
    Fonction traduit du modèle builder. Elle sert à formater les valeur dans les champs pour la suite des traitements.
    arg:
        Carte_Eco: couche des polygones écoforestier
    """

    #variable local invariable
    Code_Block = "def Reclass(GR_ESS):\\n         if len(GR_ESS)>4:\\n               return GR_ESS[:-4]\\n         elif len(GR_ESS)>2: \\n                return GR_ESS[:-2]\\n         else:\\n                return GR_ESS"
    Expression_Type = "PYTHON"
    Expression__3_ = "Reclass(!GR_ESS!)"
    Field_Name__5_ = "GR_ESS"
    #on crée une liste des attributs a changer
    field = ["GR_ESS","CL_DENS" ,"CL_PENT" ,"CL_AGE" ,"DEP_SUR" ,"CL_DRAI" ,"TYPE_COUV"]

    #On calcule le champ de group d'essence pour diminuer le nombre de caractère
    arcpy.CalculateField_management(Carte_Eco, Field_Name__5_, Expression__3_, Expression_Type, Code_Block)
    #on créer un layer pour faire une sélection sur la couche
    ecofo = arcpy.MakeFeatureLayer_management(Carte_Eco,'ecofo')
    #pour toute les champs dans la liste
    for f in field:
        #On sélectionne les valeurs nulls et les sans valeurs
        arcpy.SelectLayerByAttribute_management(ecofo,"NEW_SELECTION", '{} is null'.format(f))
        arcpy.SelectLayerByAttribute_management(ecofo, "ADD_TO_SELECTION", "{} = ''".format(f))
        #on calcul le champs pour que ce soit N
        arcpy.CalculateField_management(ecofo, f, "'N'", "PYTHON_9.3")

def rasterisation(MNT, CarteEco, DIST, workspace):
    """
    Fonction traduit d'un modèle builder. permet de transformer en raster chaque variable des couches vectoriel en vue du calcul de l'IQH.
    Arg:
        MNT: Modèle numérique de terrain d
        CarteEco: Couche de polygone écoforestier
        CoursEau: Couche du réseau hydrographique en format linéaire
        workspace:  Espace de travail où sont enregistré les éléments en sortie
    """
    # Local variables:
    Param_CL_DENS = "CL_DENS"
    Param_CL_PENT = "CL_PENT"
    Param_CL_AGE = "CL_AGE"
    Param_GR_ESS = "GR_ESS"
    Param_DEP_SUR = "DEP_SUR"
    Param_CL_DRAI = "CL_DRAI"
    Param_TYPE_COUV = "TYPE_COUV"


    # Process: Polygon to Raster
    arcpy.PolygonToRaster_conversion(CarteEco, Param_CL_DENS, workspace+"\CL_DENS.tif", "MAXIMUM_AREA", "NONE", "1")

    # Process: Polygon to Raster (2)
    arcpy.PolygonToRaster_conversion(CarteEco, Param_CL_PENT, workspace+"\CL_PENT.tif", "MAXIMUM_AREA", "NONE", "1")

    # Process: Polygon to Raster (3)
    arcpy.PolygonToRaster_conversion(CarteEco, Param_CL_AGE, workspace+"\CL_AGE.tif", "MAXIMUM_AREA", "NONE", "1")

    # Process: Polygon to Raster (4)
    arcpy.PolygonToRaster_conversion(CarteEco, Param_GR_ESS, workspace+"\GR_ESS.tif", "MAXIMUM_AREA", "NONE", "1")

    # Process: Polygon to Raster (5)
    arcpy.PolygonToRaster_conversion(CarteEco, Param_DEP_SUR, workspace+"\DEP_SUR.tif", "MAXIMUM_AREA", "NONE", "1")

    # Process: Polygon to Raster (6)
    arcpy.PolygonToRaster_conversion(CarteEco, Param_CL_DRAI, workspace+"\CL_DRAI.tif", "MAXIMUM_AREA", "NONE", "1")

    # Process: Polygon to Raster (7)
    arcpy.PolygonToRaster_conversion(CarteEco, Param_TYPE_COUV, workspace+"\TYPE_COUV.tif", "MAXIMUM_AREA", "NONE", "1")

    # Process: Copy Raster
    arcpy.CopyRaster_management(MNT, workspace+"\ELE.tif", "", "", "999", "NONE", "NONE", "", "NONE", "NONE")

    # Process: Euclidean Distance
    arcpy.CopyRaster_management(DIST, workspace+"\DIST.tif", "", "1", workspace+"\Out_direct")


def LUT(workspace):
    """
    Permet de créer le Look up Table servant a faire la compilation des variable pour la création de l'IQH.
    arg:
        workspace: Espace de travail où est enregistré le fichier

    """
    osj = os.path.join
    lookup = [(osj(workspace, "CL_DEN.tif"), "CL_DENS",  "1"),
          (osj(workspace, "CL_PENT.tif"), "CL_PENT", "1"),
          (osj(workspace, "TYPE_COUV.tif"), "TYPE_COUV", "1"),
          (osj(workspace, "C_DRAI.tif"), "CL_DRAI", "1"),
          (osj(workspace, "DEP_SUR.tif"), "DEP_SUR", "1"),
          (osj(workspace, "GR_ESS.tif"), "GR_ESS", "1"),
          (osj(workspace, "CL_AGE.tif"), "CL_AGE", "1"),
          (osj(workspace, "ELE.tif"), "ELE", "1"),
          (osj(workspace, "DIST.tif"), "DIST", "1")
          ]

    lookup2 = []


    for i in lookup:
        a= []
        for j in i:
            a.append(j.replace("\\","/"))
        lookup2.append(a)



    with open(workspace+'\Raster.csv', 'wb') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(lookup2)


def input(Carte_Eco, MNT, PointRandom, Points_de_presence, Coordinate_System, DIST, workspace,Scratch):
    """
    Fonction traduit d'un modèle builder permettant de créer les fichier à intégré dans random forest pour céer un IQH personnalisé aux données de l'utilisateur.
    Arg:
        Carte_Eco: couche des polygones écoforestier
        MNT: modèle numérique de terrain
        PointRandom: fichier de point créer alléatoirement pour simuler les points d'absence
        Points_de_presence: ficher de point de présence
        Coordinate_System: système de coordonné
        DIST: raster de la distance au cours d'eau
        workspace:  emplacement de travail où seront enregistré les sorties.
    """
    # Local variables:

    Field_Name = "Occurence"
    Drop_Field = "FID_Carte_Eco_Chateauguay_Clip_1;FID_Occurence_merge;FID_Carte_Eco_Chateauguay_Clip;GEOC_MAJ;ORIGINE;AN_ORIGINE;PERTURB;AN_PERTURB;REB_ESS1;REB_ESS2;REB_ESS3;ET_DOMI;PART_STR;CL_HAUT;ETAGEMENT;COUV_GAULE;TYPE_ECO;CO_TER;TYPE_TER;STRATE;MET_AT_STR;SUPERFICIE;TOPONYME"
    Expression__4_ = "( TYPE_COUV IS  NOT NULL ) OR (GR_ESS IS NOT NULL) OR ( CL_DENS IS NOT NULL ) OR ( CL_AGE IS NOT NULL ) OR ( CL_PENT IS NOT NULL ) OR ( DEP_SUR IS NOT NULL ) OR ( CL_DRAI IS NOT NULL )"

    # Process: Add Field (2)
    arcpy.AddField_management(PointRandom, Field_Name, "SHORT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

    # Process: Calculate Field (2)
    arcpy.CalculateField_management(PointRandom, Field_Name, "0", "VB", "")

    # Process: Create Feature Class
    presenceNofield = arcpy.CreateFeatureclass_management(Scratch, "Precences_nofield", "POINT", "", "DISABLED",
                                                          "DISABLED", Coordinate_System, "", "0", "0", "0")

    # Process: Append
    arcpy.Append_management(Points_de_presence, presenceNofield, "NO_TEST", "", "")

    # Process: Add Field
    arcpy.AddField_management(presenceNofield, Field_Name, "SHORT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

    # Process: Calculate Field
    arcpy.CalculateField_management(presenceNofield, Field_Name, "1", "VB", "")

    # Process: Merge
    Occurence_merge = arcpy.Merge_management([PointRandom, presenceNofield], Scratch + "\Occurence_merge",
                                             "Occurence \"Occurence\" true true false 2 Short 0 0 ,First,#,PointRandom,Occurence,-1,-1,F:\\Data_Salamandre\\Salamandre.gdb\\Precences_nofield,Occurence,-1,-1")

    # Process: Intersect
    Occurence_intersect = arcpy.Intersect_analysis([Carte_Eco, Occurence_merge], Scratch + "\Occurence_intersect",
                                                   "ALL", "", "POINT")

    # Process: Extract Values to Points
    Output = arcpy.gp.ExtractValuesToPoints_sa(Occurence_intersect, MNT, Scratch + "\Output", "NONE", "VALUE_ONLY")

    # Process: Alter Field
    Output2 = arcpy.AlterField_management(Output, "RASTERVALU", "ELE", "ELE")

    # Process: Extract Values to Points (2)
    Output3 = arcpy.gp.ExtractValuesToPoints_sa(Output2, DIST, Scratch + "\Output3", "NONE", "VALUE_ONLY")

    # Process: Alter Field (2)
    Output4 = arcpy.AlterField_management(Output3, "RASTERVALU", "DIST", "DIST")

    # Process: Delete Field
    Output5 = arcpy.DeleteField_management(Output4, Drop_Field)

    # Process: Select
    arcpy.Select_analysis(Output5, workspace + '\Occurence', Expression__4_)

def segmentation(CoursEau,Segmentation_Number, workspace):
    """
    Fonction permettant de faire la segmentation du réseau hydrographique. Le chemin de la toolbox de segmentation doit être changer.
    Arg:
        CoursEau: réseau hydrographique
        Segmentation_Number: logueur des segments désirés
        workspace: espace de travail où seront enregistrer les sorties
    """
    # Process: Feature Line Split
    #***le chemin doit être mis à jour selon l'ordinateur utilisé***
    arcpy.gp.toolbox = chemin #r"D:/APP2/Conception modules/FeatureLineSplit-master/FeatureLineSplit-master/Feature Line Split.tbx";
    # Warning: the toolbox D:/APP2/Segmentation/FeatureLineSplit-master/FeatureLineSplit-master/Feature Line Split.tbx DOES NOT have an alias.
    # Please assign this toolbox an alias to avoid tool name collisions
    # And replace arcpy.gp.FeatureLineSplit(...) with arcpy.FeatureLineSplit_ALIAS(...)
    arcpy.gp.FeatureLineSplit(CoursEau, Segmentation_Number, "", "LENGTH", "true", workspace+'\segmentation')

def main():
    """
    Workspace = espace de travail
    projection = la projection désirer pour le projet
    zone = la délimitaion de la zone d'étude
    MNT = modèle numérique de terrain
    Ecofo = couche des polygones écoforestier
    hydro = couche hydrographique linéaire
    buf = distance du buffer à partir du cours d'eau
    segement = longueur du segment de cours d'eau désirer
    occurence = point de présence de salamandres
    resurgence = point de résurgence

    """

    workspace = arcpy.GetParameterAsText(0)
    zone = arcpy.GetParameterAsText(1)
    MNT = arcpy.GetParameterAsText(2)
    Ecofo = arcpy.GetParameterAsText(3)
    hydro = arcpy.GetParameterAsText(4)
    buf = arcpy.GetParameterAsText(5)
    segment = arcpy.GetParameterAsText(6)
    occurence = arcpy.GetParameterAsText(7)
    resurgence = arcpy.GetParameterAsText(8)

    descFeauture = arcpy.Describe(zone)
    Xmin = descFeauture.extent
    extent = Xmin
    arcpy.env.extent = extent
    mxd = mapping.MapDocument("CURRENT")
    #***Chemin à changer***
#    symbology = r"C:\Users\cuistooo\Documents\Ecole\Uni\2018hiv\APP2\Rasters_IQH\symbology.lyr"

    if not arcpy.Exists(workspace+"/Scratch.gdb"):

        #Initialisation de l'espace de travail.
        arcpy.CreateFileGDB_management(workspace, "Scratch.gdb")

    # On crée la GDB où les données de traitement son envoyer.
    arcpy.env.workspace = workspace+"/Scratch.gdb"
    # je déclare un espace de travail pour l'ensemble du travail
    Scratch = arcpy.env.workspace

    arcpy.AddMessage(Scratch)
    arcpy.AddMessage(
        "=======================================" + "\n" + "Projection des couches" + "\n" + "=======================================")

    # récupération de la référence spatiale du MNT
    descFeature = arcpy.Describe(MNT)
    projection = descFeature.spatialReference

    # Projetion des couches, copy du MNT
    projetCouche(projection, zone, Scratch, "Zone")
    arcpy.AddMessage("Zone d'étude")
    arcpy.CopyRaster_management(MNT, Scratch + "\MNT_p")
    arcpy.AddMessage("MNT")
    projetCouche(projection, Ecofo, Scratch, "Ecofo")
    arcpy.AddMessage("Écoforestier")
    projetCouche(projection, hydro, Scratch, "HydroL")
    arcpy.AddMessage("Hydrographie")


    # Tente de faire la projetion de la couche si c'est en erreur cela donne un message.
    try:
        projetCouche(projection, occurence, Scratch, "Occurence")
        arcpy.AddMessage("Occurence")
    except:
        arcpy.AddMessage("Aucune observation de salamandes")
    try:
        projetCouche(projection, resurgence, Scratch, "ResurgenceP")
        arcpy.AddMessage("Résurgence")
    except:
        arcpy.AddMessage("Aucune résurgence")


    arcpy.AddMessage(
        "=======================================" + "\n" + "Découpage des couches selon la zone d'etude" + "\n" + "=======================================")

    #appel de la fonction qui découpe les couches
    decoupeFeature(Scratch)
    #liste les couches contenu dans l'espace de travail
    couches = arcpy.ListFeatureClasses()

    #pour toutes les couches dans l'espace de travail on sort les éléments type et nom
    for couche in couches:
        descFeauture = arcpy.Describe(couche)
        name = descFeauture.baseName
        Xmin = descFeature.extent
        #si la couche a pour nom Zone_p on  la définit comme étant la zone
        if name == "Zone_p":
            zone = couche
            extent = Xmin
    Zone = arcpy.MakeFeatureLayer_management(zone,"zone")
    outExtractByMask = ExtractByMask(MNT, Zone)
    outExtractByMask.save(Scratch+"/MNT_p_clip")


    arcpy.AddMessage(
        "=======================================" + "\n" + "Segmentation des cours d'eau" + "\n" + "=======================================")

    #vérification de la version arc gis si < que 10.3 passer sinon faire la
    couches = arcpy.ListFeatureClasses()
    # pour chaque couche, on sort le nom
    for couche in couches:
        descFeauture = arcpy.Describe(couche)
        name = descFeauture.baseName
        # si le nom est celui de la couche Occurence on définit la variable Occurence
        if name == "HydroL_p_clip":
            Hydro = couche

    couches = arcpy.ListRasters()
    for couche in couches:
        descFeauture = arcpy.Describe(couche)
        name = descFeauture.baseName
        if name == "MNT_p_clip":
            MNT = couche

    segmentation(Hydro, segment, Scratch)

    arcpy.AddMessage(
        "=======================================" + "\n" + "Création des masques sur les cours d'eau" + "\n" + "=======================================")

    couches = arcpy.ListFeatureClasses()

    for couche in couches:
        descFeature = arcpy.Describe(couche)
        name = descFeature.baseName
        # si le nom est celui de la couche des segments hydrographique on définit la variable seghydro
        if name == "segmentation":
            seghydro = couche
        # si le nom est celui de la couche resurgence on définit la variable resurgence
        if name == "ResurgenceP_p_clip":
            resurgence = couche

    try:

        # Essais de faire la zone tampon autoure des résurgences. si tu y arrive join les deux zone tampon.
        resuBuf = arcpy.Buffer_analysis(resurgence, Scratch + "/resuBuf", buf + " Meters", "FULL", "ROUND")
        # Création de la zone tampon autour des rivières
        hydroBuf = arcpy.Buffer_analysis(seghydro, Scratch + "/hydroBuf", buf + " Meters", "FULL", "FLAT")
        arcpy.Merge_management([hydroBuf, resuBuf], Scratch+"/hydroBuff")

    except:
        # Création de la zone tampon autour des rivières
        arcpy.Buffer_analysis(seghydro, Scratch + "/hydroBuff", buf + " Meters", "FULL", "FLAT")

    arcpy.AddMessage(
        "=======================================" + "\n" + "Préparation des variables" + "\n" + "=======================================")


    # on liste les couche dans l'espace de travail
    couches = arcpy.ListFeatureClasses()
    # pour chaque couche, on sort le nom
    for couche in couches:
        descFeauture = arcpy.Describe(couche)
        name = descFeauture.baseName
        # si le nom est celui de la couche Ecofo on définit la variable Ecofo
        if name == "Ecofo_p_clip":
            Ecofo = couche
        # si le nom est celui de la couche Occurence on définit la variable Occurence
        if name == "Occurence_p_clip":
            Occurences = couche



    pretraitementEco(Ecofo)
    DIST = arcpy.gp.EucDistance_sa(Hydro, Scratch + "\DIST", "", "1", Scratch + "\Out_direct")

    try:

        # on appel la fonction qui crée les points d'absence
        pointsAbs(Ecofo, Occurences, Scratch)
        arcpy.AddMessage("les point d'absences ont été créer")

        # on liste les couche dans l'espace de travail
        couches = arcpy.ListFeatureClasses()
        # pour chaque couche, on sort le nom
        for couche in couches:
            descFeauture = arcpy.Describe(couche)
            name = descFeauture.baseName
            # si le nom est celui de la couche Ecofo on définit la variable Ecofo
            if name == "absence":
                PointRandom = couche

        couches = arcpy.ListRasters()
        for couche in couches:
            descFeauture = arcpy.Describe(couche)
            name = descFeauture.baseName
            if name == "MNT_p_clip":
                MNT = couche

        try:
            arcpy.AddMessage("Création du fichier pour le calcul des variables")
            input(Ecofo, MNT, PointRandom, Occurences, projection, DIST, workspace, Scratch)
        except:
            arcpy.AddMessage("erreur")

    except:
        arcpy.AddMessage("Pas d'occurence")

    arcpy.AddMessage("Transformation des couches en matrice.")
    rasterisation(MNT, Ecofo, DIST, workspace)  # définir un environnement d'extend = zone
    arcpy.AddMessage("Création du fichier csv.")
    arcpy.env.workspace = workspace
    workspace =arcpy.env.workspace
    LUT(workspace)



    #On prend la couche d'IQH, on lui applique une symbologie puis on l'ajoute au document courant.
    # df = arcpy.mapping.ListDataFrames(mxd, "Layers")[0]
    # addLayer = arcpy.mapping.Layer(IQH)
    # arcpy.ApplySymbologyFromLayer_management(addLayer, symbology)
    # arcpy.mapping.AddLayer(df, addLayer, "BOTTOM")


if __name__ == '__main__':

    main()