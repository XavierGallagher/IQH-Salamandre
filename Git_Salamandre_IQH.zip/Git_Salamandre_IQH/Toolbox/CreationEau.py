# -*- coding: utf-8 -*-
"""
Script permettant de créer un réseau hydrographique à l'aide de l'aire de drainage.
version préliminaire

Créer par la Sal'Équipe dans le cadre du cours APP de l'université de Sherbrooke
        Gabriel Boisvert
        Xavier Gallagher-Duval
        Audrey Oliver

        Avril 2018
"""

#importation des librairies
import arcpy
import ArcHydroTools as ah #Il faut que l'extension arcHydro soit installer sur l'ordinateur.
from arcpy.sa import *

#Permet de s'assurer que l'extention spatial analyst est cocher.
arcpy.CheckOutExtension("spatial")

def main():

    #Définission des variables à entré par l'utilisateur
    workspace = arcpy.GetParameterAsText(0)
    MNT = arcpy.GetParameterAsText(1)
    Number_of_cells_to_define_stream = arcpy.GetParameterAsText(2)

    # variable fixe dans le script
    Maximum_thickness_of_input_linear_features = "1"
    Minimum_dangle_length = "10"
    Extend_Length = "3 Meters"
    Dangle_Length = "3 Meters"


    #Initialisation de l'espace de travail.
    arcpy.CreateFileGDB_management(workspace, "Scratch.gdb")

    # On crée la GDB où les données de traitement son envoyer.
    arcpy.env.workspace = workspace+"/Scratch.gdb"
    # je déclare un espace de travail pour l'ensemble du travail
    Scratch = arcpy.env.workspace

    #Les couches intermédiaires seront enregistrés dans la Scratch
    # Process: Fill
    Fill__2_ = arcpy.gp.Fill_sa(MNT, Scratch + "/fill", "")

    # Process: Flow Direction
    FlowDir = arcpy.gp.FlowDirection_sa(Fill__2_, Scratch + "/FlowDir", "NORMAL", Scratch + "/drop_raster")

    # Process: Flow Accumulation
    Flow_Acc = arcpy.gp.FlowAccumulation_sa(FlowDir, Scratch + "/Flow_Acc", "", "INTEGER")

    # Process: Stream Definition
    str = ah.StreamDefinition(Flow_Acc, Number_of_cells_to_define_stream, Scratch + "/str", "0")

    # Process: Raster Calculator
    rastercalc = Con(IsNull(str), FocalStatistics(str, NbrRectangle(4, 4), "MEAN"), str)
    rastercalc.save(Scratch + "/rastercalc")

    # Process: Int
    Int__2_ = arcpy.gp.Int_sa(rastercalc, Scratch + "/Int__2_")

    # Process: Thin
    Thin__2_ = arcpy.gp.Thin_sa(Int__2_, Scratch + "/Thin__2_", "ZERO", "NO_FILTER", "ROUND", Maximum_thickness_of_input_linear_features)

    # Process: Raster to Polyline
    TestCoursEauMod = arcpy.RasterToPolyline_conversion(Thin__2_, Scratch + "/test", "ZERO", Minimum_dangle_length, "SIMPLIFY", "Value")

    # Process: Extend Line
    TestCoursEauMod__2_ = arcpy.ExtendLine_edit(TestCoursEauMod, Extend_Length, "EXTENSION")

    # Process: Trim Line
    TestCoursEauMod__3_ = arcpy.TrimLine_edit(TestCoursEauMod__2_, Dangle_Length, "KEEP_SHORT")

    # La couche d'hydrographie est  creér et enregistrer dans l'espace de travail
    arcpy.UnsplitLine_management(TestCoursEauMod__3_, workspace + "/HydroL", "", "")


if __name__ == '__main__':

    main()
