﻿


Structure du dossier Projet_SalEquipe. 
Ce readme.txt contient les détails des différents dossiers réalisées dans le cadre du projet app. 
Sal’Équipe : Gabriel Boisvert, Xavier Gallagher-Duval, Audrey Oliver
Date : Août 2018.
=================================================================================================================
Version ArcGIS
La version d’ArcGIS nécessaire à faire rouler la ToolBox est 10.4. 
=================================================================================================================



Pour utiliser les produits contenus dans ce dossier, vous devez d’abord utiliser la boite à outils ArcGIS retrouvée 
dans le dossier ToolBox. Dans ce dossier, vous retrouverez un guide d’utilisation de l’outil ainsi que la ToolBox 
elle-même. 

Dans le fichier Script_R, vous retrouverez un guide d’utilisation, Tutoriel_IQH, le modèle déjà 
généré ModelRF.RDS ainsi que deux scripts. Le premier Application_IQH permet d’appliquer le modèle 
d’IQH sur un territoire voulu et préparé avec la ToolBox. Le script Création_IQH, permet de créer son propre 
modèle d’IQH lorsque vous avez des données d’observations de salamandres de ruisseaux. 



#=====================================================================================================================