
#
# Scipt d'application d'un IQH sur des données Géospatiales pour la salamandre pourpre. 


# Installation des packages nécessaires pour l'utilisation du script. 

list.of.packages <- c("ModelMap", "rgdal","caret", "tidyverse", "data.table", "plyr", "dplyr", "tidyr")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages) > 0) {install.packages(new.packages)}
lapply(list.of.packages, require, character.only=T)

library(rgdal)
library(ModelMap)
library(plyr)
library(dplyr)
library(tidyr)
library(tidyverse)

# Sélection du répertoire de travail
dossier <- choose.dir(default = "", caption = "Choisir répertoire de travail")
dossier_travail <- DirecName <- gsub("\\", "/", dossier, fixed = TRUE)

# Importation du fichier contenant les points d'observations

DataSHP <- data.frame(readOGR(file.choose(new=FALSE)))

# Transformation de la valeur de l'élévation d'integer à numerique
DataSHP$ELE <- as.numeric(as.character(DataSHP$ELE))
attach(DataSHP)
VarSHP <- as.data.frame(cbind(GR_ESS, CL_DENS, CL_AGE, CL_PENT, DEP_SUR, CL_DRAI, ELE, TYPE_COUV, Occurence, DIST))
detach(DataSHP)
attach(VarSHP)

# Réduction du code de groupe d'essence de 6 à 2 lettres
VarSHP$GR_ESS <- strtrim(VarSHP$GR_ESS, 2)
table(VarSHP$GR_ESS)
VarFactor <- rbind(GR_ESS, CL_DENS, CL_AGE, CL_PENT, DEP_SUR, CL_DRAI, ELE, TYPE_COUV, Occurence, DIST)
Data_mat <- t(VarFactor)

# Factorisation des variables catégoriques (transformation en chiffre)
DataModel <- as.data.frame(Data_mat)
detach(VarSHP)


#===============================================================================
# Création de la fonciton qui permet de générer automatiquement un modèle
#===============================================================================

ModelCreation <- function(DataModel, dossier_travail){
  
  #Création de l'identifiant unique de chacune des observations
  DataModel<- tibble::rowid_to_column(DataModel, "ID")
  unique.rowname <- "ID" 
  
  # Liste des prédicteurs pris en compte dans l'IQH 
  predListRF <- c("GR_ESS", "CL_DENS", "CL_AGE", "CL_PENT", "DEP_SUR", "CL_DRAI", "ELE", "DIST","TYPE_COUV") #"GR_ESS",  n'est pas pris en compte
  
  #Liste des prédicteurs catégoriques transformés en facteurs
  predFactorRF <- c("GR_ESS", "CL_DENS", "CL_AGE", "CL_PENT", "DEP_SUR", "CL_DRAI", "TYPE_COUV")
  
  #Spécification du nom de colonne de la vairable réponse et du type de modèle
  response.nameRF="Occurence"
  response.typeRF="binary"
  
  #Nombre d'arbres de décisions générés
  ntreeRF <- as.integer(500)
  
  ModelFinal <- "ModelName"
  folder=dossier_travail
  
  #=======================================================
  # Création du modèle
  #=======================================================
  
  NouveauModelRF <<- model.build(model.type = "RF",
                                qdata.trainfn = DataModel,
                                folder = folder,
                                unique.rowname = unique.rowname,
                                MODELfn = ModelFinal,
                                predList = predListRF,
                                predFactor = predFactorRF,
                                response.name = response.nameRF,
                                response.type = response.typeRF, 
                                seed = 69,
                                ntree = ntreeRF,
                                mtry = 3,
                                na.action = "na.omit")
  
  
  #=========================================================
  # Création des statistiques d'évaluations
  #=========================================================
  
  
  # Evaluation du modèle avec le Out-of-Bag Error. 
  Pred_OOB <<- model.diagnostics(model.obj = NouveauModelRF, 
                                qdata.trainfn = DataModel,
                                folder = folder, 
                                unique.rowname = unique.rowname, 
                                prediction.type = "OOB",
                                MODELpredfn = NULL,
                                device.type = c("pdf"),
                                na.action = "na.omit",
                                cex = 0.6)
  
  return(NouveauModelRF)
  return(Pred_OOB)
  
  
  #=========================================================
  # Création d'une table contenant le RMSD, Rsquared, et AUC, ROC
  #================================================================
  
   
}
ModelCreation(DataModel, dossier_travail)

Perfo_Eval<- function(Pred_OOB, dossier_travail){

  # Chercher les valeurs prédites et observées
  RF_Diagnostic <- Pred_OOB
  RF_Observed <- RF_Diagnostic$obs
  RF_Predicted <- RF_Diagnostic$pred
  #y <- RF_Predicted
  #x <- RF_Observed

  n <- length(RF_Diagnostic[ ,c(1)])  #Nombre d'observations
  SSres<-sum((RF_Observed - RF_Predicted)^2)
  SStot<-sum((RF_Observed-(mean(RF_Predicted)))^2)
  R2<-1-(SSres/SStot) #matches output from model map
  MSE<-mean((RF_Observed-RF_Predicted)^2) #matches output from modelmap
  RMSD<-sqrt(sum((RF_Observed-RF_Predicted)^2)/(n)) # matches graph
  Bias <- sum(RF_Observed-RF_Predicted)/n

  # Enrefistrement de la table.
  
  RF_Stats_Perfo <- c(R2, MSE, RMSD, Bias)

  
  return(RF_Stats_Perfo)

}

# Création du fichier CSV des performances du modèles. 
Perfo_Eval(Pred_OOB, dossier_travail)
names(RF_Stats_Perfo) <- c("R2", "MSE","RMSD", "Bias")
PerfoData <- as.data.frame(RF_Stats_Perfo)
NamePerfo <- paste(dossier_travail, "PerformanceModel.csv", sep = "/")
write.csv(PerfoData, file = NamePerfo)




# sauvegarde du nouveau model
NameModel <-file.choose(new = FALSE)
save(NouveauModelRF, file = NameModel)
