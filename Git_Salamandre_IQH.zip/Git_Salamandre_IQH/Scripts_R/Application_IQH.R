#
# Scipt d'application d'un IQH sur des données Géospatiales pour la salamandre pourpre. 


# Installation des packages nécessaires pour l'utilisation du script. 

list.of.packages <- c("ModelMap", "rgdal","caret", "tidyverse", "data.table", "plyr", "dplyr", "tidyr")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages) > 0) {install.packages(new.packages)}
lapply(list.of.packages, require, character.only=T)

library(rgdal)
library(ModelMap)
library(plyr)
library(dplyr)
library(tidyr)
library(tidyverse)


# Définition de la fonction d'application du modèle existant 
# sur une nouvelle zone d'étude. 

ModelAppli <- function(csvName, ModelRF, OutputName, repertoire){
  
  folder <- repertoire_travail
  
  # Importation du fichier CSV de la LookUp Table
  # appel de la lookup table qui contient les chemins d'accès des rasters des predicteurs
  
  rastLUT <- csvLUT 
  rastLUT<- read.table(rastLUT, header=FALSE, sep=",",stringsAsFactors=FALSE)
  
  
  # Création de la carte d'IQH avec le modèle. 
  
  modelCreation <- model.mapmake( model.obj=ModelRF, # modèle RF IQH sélectionné
                                  folder=folder, #<- dossier de travail
                                  MODELfn=NULL, #<- nom automatique pour le produit final
                                  rastLUTfn=rastLUT, # <- nom de l'objet contenant le LookUp Table
                                  na.action="na.omit", # <- Action à prendre lorsqu'il y a des valeurs nulles
                                  OUTPUTfn=OutputName) #<- Nom du fichier en sorti
  
  return(modelCreation)
  
  
}

repertoire <- choose.dir(default = "", caption = "Choisir répertoire de travail")
repertoire_travail <- DirecName <- gsub("\\", "/", repertoire, fixed = TRUE)
csvName <-(file.choose(new = FALSE))
csvLUT <- gsub("\\", "/", csvName, fixed = TRUE)


#LookUpTable <- file.path(csvLUT)

ModelRF <- file.choose(new = FALSE)
ModelRF <- readRDS(file.path(ModelRF))
OutputFolder<- choose.dir(default = "", caption = "Choisir un dossier")
DirecName <- gsub("\\", "/", OutputFolder, fixed = TRUE)
name <- paste("IQH.tif", sep="")
OutputName <- file.path(DirecName, name)


ModelAppli(csvName, ModelRF, OutputName)